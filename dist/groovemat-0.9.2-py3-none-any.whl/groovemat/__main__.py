from groovemat.cli import cli  # Adjust the import path as needed


def main():
    from .cli import cli

    cli()


if __name__ == "__main__":
    main()
