# Disco

Get your atoms moving!

## Overview

This software package uses the Crystal Graph Convolutional Neural Networks (CGCNN) framework and M3gnet to create an un-supervised GNN that converges the internal degrees of freedom of a crystal lattice.

# Download

```
pip install disco
```

